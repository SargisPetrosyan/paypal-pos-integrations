from typing import TypedDict
from typing import Literal
from dotenv import load_dotenv
load_dotenv()

class Response(TypedDict):
    message: str

class WebhookSuccessReturn(TypedDict):
    status: str
    response: Response

PAGE_SIZE_FOR_LIST_FILES: int = 100

# Shop names:
DALA_SHOP_NAME: Literal["dala"] = "dala"
ART_AND_CRAFT_NAME: Literal["art"] = "art"
CAFE_NAME: Literal["cafe"] = "cafe"

SHOPS: tuple = (DALA_SHOP_NAME, ART_AND_CRAFT_NAME, CAFE_NAME)
TIME_INTERVAL_MINUTE: int = 30

SWEDEN_TIMEZONE_NAME = "Europe/Stockholm"
UTC_TIMEZONE_NAME = "UTC"

PAYPAL_GRANT_TYPE = "urn:ietf:params:oauth:grant-type:jwt-bearer"
PAYPAL_AUTH_URL = "https://oauth.zettle.com/token"
PAYPAL_HEADERS = "application/x-www-form-urlencoded"


SHOP_SUBSCRIPTION_EVENTS: list[str] = ["InventoryBalanceChanged"]

WEBHOOK_SUCCEEDED_RETURN:WebhookSuccessReturn= {
    "status": "200",
    "response": {
        "message": "Webhook Succeeded",
    }
}

ACCESS_KEY_EXPIRES_DATE: str = "access_key_expiration_date"
WEBHOOK_NAME:str = "inventory_tracker_webhook"
WEBHOOK_LOG_FILE: str = "webhook/logs/data_registry_logs.log"

AURORA_DSQL_ZONE:str = "eu-north-1"

AURORA_DSQL_USER:str = "admin"
INVENTORY_DB_TABLE_NAME:str = "inventory"
SIGNING_KEY_TABLE_NAME:str = "signingkey"
