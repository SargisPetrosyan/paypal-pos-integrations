import shutil
import subprocess
from pathlib import Path

project_dir = Path(__file__).resolve().parents[1]
repo_dir = project_dir.parent
package_dir = project_dir / "packages"
shared_package_dir = package_dir / "shared"

subprocess.run(
    [
        "uv",
        "pip",
        "install",
        "--target",
        str(package_dir),
        "--python-platform",
        "x86_64-manylinux2014",
        "--python-version",
        "3.13",
        "--only-binary",
        ":all:",
        "aurora-dsql-python-connector",
        "psycopg[binary,pool]",
        "python-dotenv",
        "pytz",
    ],
    check=True,
)

subprocess.run(
    [
        "pip",
        "install",
        "--platform",
        "manylinux2014_x86_64",
        "--target",
        str(package_dir),
        "--implementation",
        "cp",
        "--python-version",
        "3.13",
        "--only-binary=:all:",
        "--upgrade",
        "pydantic[email]",
    ],
    check=True,
)

shared_package_dir.mkdir(parents=True, exist_ok=True)

for filename in ("__init__.py", "constants.py", "inventory_models.py", "logging.py"):
    shutil.copy2(repo_dir / "shared" / filename, shared_package_dir / filename)

for filename in ("lambda_function.py", "db_connect.py", "models.py", "utils.py"):
    shutil.copy2(project_dir / filename, package_dir / filename)

archive = repo_dir / "my_deployment_package.zip"
archive.unlink(missing_ok=True)

subprocess.run(
    ["zip", "-r", str(archive), "."],
    cwd=package_dir,
    check=True,
)